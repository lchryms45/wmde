README OneStepBack

==Summary==

- [#1 OneStepBack]
- [#2 Version]
- [#3 Screenshots]
- [#4 Installation]
- [#5 Author]
- [#6 Licence]
- [#7 Web pages]
- [#8 Color variations]
- [#9 Known Bugs]
- [#10 Changelog]
- [#11 Version numbering]
- [#12 Download]

==[#1] OneStepBack==

OneStepBack is a Gtk 2, 3 and 4 theme with some colors and embossed widgets inspired by the good old [NeXTSTEP https://en.wikipedia.org/wiki/NeXTSTEP] look. I'm old.

It is developed from scratch, is light and minimal, uses only three shades of grays and one color. That was the challenge.

It has been tested on Arch Linux with Gnome-Shell, Gtk+ from 3.16 to 3.24 and Gtk+ 4.12.4, a good amount of Gtk2 and Gtk3 applications and a very few Gtk4 applications. A lot of widget controls are still missing (but the defaults should be good enough) and it is not tested at all with unity or xfce.

==[#2] Version==

Current version is 0.997, released in March 2024.

==[#3] Screenshots==

The screenshots show OneStepBack theme and a slightly darker and contrasty variation : OneStepBack-wm2. They show also : [Ubo Icons Theme https://www.gnome-look.org/p/1012539/] with personal additions, [Dash to Dock https://extensions.gnome.org/extension/307/dash-to-dock/] and [Dynamic Top Bar https://extensions.gnome.org/extension/885/dynamic-top-bar/] Gnome Shell extensions.

==[#4] Installation==

To install the theme, unzip the archive and copy the theme in your theme directory, usually ``~/.local/share/themes``. There is no need for any extra //engine//.
% For Arch Linux users, see below our [#Aur packages] for system installation.

To make the change effective, //right now in January 2024//, you will have to :

- put ``export GTK_THEME=OneStepBack`` in your ``~/.xprofile`` file;

- use the application ``gnome-tweaks`` and select OneStepBack in ``Appearance/Legacy Appplications``.

- then, log out from your XWindow or Wayland session and restart it.

I know, this is now ridiculously complicated.

Tip : QT applications can use some base colors of the gtk theme after installing ``qt5-styleplugins`` and ``qt6gtk2``, for a more consistent overall appearance.

==[#5] Author==

The author is [Jean-Pierre Bucciol jpsspam(at)free.fr].

==[#6] Licence==

This is a [GPL 3 https://www.gnu.org/licenses/gpl.txt] free software. Feel free to change and share the code.

==[#7] Web pages==

- [OneStepBack theme main page  http://www.vide.memoire.free.fr/perso/OneStepBack/onestepback.php]

- [OneStepBack at gnome-look.org http://www.gnome-look.org/p/1013663]

==[#8]  Colors variations==

The dominant colors of the theme are easy to change. They are defined in the first lines of files ``gtk-2.0/gtk2rc``, ``gtk-3.0/gtk.css`` and ``gtk-4.0/gtk.css``. For example, for a [WindowMaker https://www.windowmaker.org/]-like version, try to change in ``gtk-2.0/gtk2rc`` :

```
gtk-color-scheme = "white_color:#ffffff
lighter_color:#eeeeee
base_color:#888888
darker_color:#666666
black_color:#000000
scale_color:#4b6983
"

gtk-color-scheme = "button_selected_bg_color:#686868
text_selected_bg_color:#686868
text_selected_fg_color:#ffffff
menuitem_selected_bg_color:#efeeed
menuitem_selected_fg_color:#000000
listitem_selected_bg_color:#686868
listitem_selected_fg_color:#ffffff
"
```

In ``gtk-3.0/gtk.css`` and ``gtk-4.0/gtk.css`` :

```
@define-color white_color #ffffff;
@define-color lighter_color #eeeeee;
@define-color base_color #888888;
@define-color darker_color #666666;
@define-color black_color #000000;
@define-color scale_color #4b6983;

@define-color headerbar_bg_color #000000;
@define-color button_selected_bg_color #686868;
@define-color text_selected_bg_color #686868;
@define-color text_selected_fg_color #ffffff;
@define-color menuitem_selected_bg_color #efeeed;
@define-color menuitem_selected_fg_color #000000;
@define-color listitem_selected_bg_color #686868;
@define-color listitem_selected_fg_color #ffffff;
@define-color text_view_bg @lighter_color;
```

==[#9] Known Bugs==

- LibreOffice : black color on black background in some widgets : unfortunatly, nothing I can do. Workaround : please try to put "``export SAL_USE_VCLPLUGIN=kf5``" in your ``~/.xsessionrc`` file  (or ``~/.xprofile``, or ``~/.bashrc``) and restart your X session.

- Firefox, Thunderbird and QT applications : arrow buttons shape and colors, color of active menu items : unfortunatly, nothing I can do.

- gtk4 port is very experimental !

==[#10] Changelog==

Version 0.998, working version

Version 0.997, March 2024
- gtk4: improve button image:active
- gtk3: fix a bug in background-color of headerbar button:active:hover
- gtk4: fix a bug in headerbar color name
- gtk4: improve switch widget in list
- gtk3: fix inconsistencies in outset and inset widgets
- gtk3: fix a color bug in switch widget
- gtk3: fix a bug in label of disabled combobox button
- gtk4: improve listview widget
- gtk3-4: all headerbar widgets turn gray when backdrop
- gtk4: improve spinbutton text widget

Version 0.996, February 2024
- gtk4: improve progressbar and scale widgets
- gtk4: improve embossed widgets
- gtk3-4 : add minimal support of tooltip widget
- gtk3-4: improve separators; remove vertical separator in headerbar
- gtk4: improve arrows in menus
- gtk3-4: improve notebook top and left tabs borders
- gtk3-4: fix color inconsistencies in disabled labels and spinbuttons
- gtk3-4: the close button in headerbars now turns red or orange when hover
- gtk3-4: add a gray change on buttons in headerbar when hover.
- gtk3: fix some inconsistencies in label of disabled menuitems
- gtk3-4: fix a color bug in the label of disabled check buttons.
- gtk3-4: lower the minimum height of the headerbars
- gtk4: improve some calendar widgets
- change slightly  the base and lighter colors
- gtk3: fix a mismatch of the different versions where the derived colors were harded coded

Version 0.995, January 2024
- gtk3: fix a bug with the height of titlebar
- gtk3: fix a bug in radius of titlebar
- modify the colors of the darker variant for more contrasts
- gtk4: reworking of the windows shadows
- gtk3: fix a wrong foreground color in thunderbird titlebar
- gtk4: add some calandar widgets
- gtk4: works now with mutter, but it's crude. Problably needs some reworking.
- gtk3: foreground selection color hack for evince.

Version 0.994, February 2022
- gtk4: bug introduced with the new version of gtk4 : color of the window title : fixed
- gtk4: genuine version was using the darker colors ! Fixed

Version 0.993, November 2021
- gtk3: change behaviour for label disactived color
- gtk4: first very experimental port

Version 0.992, November 2020
- keep only one variant, slightly darker.
- gtk3: fix a color bug in message dialog headerbar
- gtk3: fix a color name bug
- gtk3: improve color selection of button:active:hover and button:checked:hover.
- gtk3: remove some obsolete tweaks
- gtk3: compatibility with gtk 3.24 checked
- add a darker variant: OneStepBack-darker
- gtk3: hack fix a color bug in gnome terminal 3.36.2

Version 0.991, July 2018
- change the grey-brown color variant for a grey-brown-green-blue color variant
- gtk2: improve generation of the derived colors
- gtk2: improve colors of progressbar label
- gtk3: improve color backdrop color in headerbar
- gtk3: improve button color consistency in headerbar
- gtk3: fix a bug in toolbar button hover
- gtk3: fix a color name bug
- improve differentation of selected text, menuitem and listitem colors

Version 0.99, April 2018
- gtk3: improve spacing for icons in nautilus sidebar
- gtk3: fix a color name bug
- add a grey-brown color variant

Version 0.98, March 2018
- gtk3: fix a color bug when toogle button in hover
- fix a bug in the headerbar roundness
- fix a color bug in the windows shadows
- improve design of the thumbs on scales and scrollbars
- improve colors of arrows and scrollbars
- improve support for easy color changes
- change colors of the variant color version: the colors are inspired by the earth-brown gtk3 theme

Version 0.97, January 2018
- gtk3: fix a color bug in the flotting bottom information bar in nautilus
- add a color variant
- gtk3: fix a color bug in popover (modelbutton:active)
- gtk3: drop support for gtk 3.16 and 3.18

Version 0.96, July 2017
- fix a color bug for mouse color selection in caja (mrnhmath)

Version 0.95, July 2017
- fix a color bug for background in icon view in caja (mrnhmath)
- fix a color name bug

Version 0.94, July 2017
- fix a color bug for selected and unfocused wxgtk items

Version 0.93, May 2017
- gtk3: fix a color bug in nautilus for selected and unfocused icons
- gtk3: fix a color bug for selections in firefox gtk3
- change for a blue-gray color for progress bars and switch

Version 0.92: November 2016
- gtk3: fix a color bug in headerbar pathbar
- gtk3: add a left margin to arrow in menus
- gtk2: fix wrong background color in rox when switching theme
- gtk3: improve css syntax for font definitions

Version 0.91, September 2016
- gtk3: disable the GtkWidget-window-dragging function that breaks things in gnumeric (thanks Ingo S.)

Version 0.9, August 2016
- add support for easy color changes
- gtk3: add a minimal lenght to the scrollbar sliders
- gtk3: improve arrows design in scrollbar when disabled

Version 0.8, April 2016
- gtk3: fix a bug in desktop borders when nautilus manages the desktop
- gtk3: more consistant design of the scrollbar arrow buttons
- gtk3: add support for scale indicators
- gtk3: fix bug for scale sliders overpassing trough
- gtk3: fix a bug with labels of scale bars
- gtk3: add support for arrows in popover menus
- gtk3: change behaviour of the checked button in hea.derbar
- gtk3: add basic support for calendar and iconview widgets
- gtk3: fix a color bug for radiobutton label when disabled in list
- gtk3: add support for expander arrows when active

Version 0.7, April 2016
- gtk3: port to gtk 3.20: gtk3 part rebuild from scratch !
- orange progress bar color
- gray active widgets
- no more highlight on hover

Version 0.6, November 2015
- gtk3: improve borders of menus (thanks behrz)

Version 0.5, October 2015
- gtk3: improve borders/shadows to better match the gtk2 part (thanks behrz)
- gtk3: improve switch borders
- fix some colors and rocking in toolbar buttons
- change borders of scrollbar sliders to match the new button shadows
- gtk2: better centering of the scrollbar thumb
- gtk3: fix a padding problem in gedit open document popover (thanks to bd209ocp)

Version 0.4, October 2015
- gtk3: fix some color and padding tweeks for nautilus 3.18
- add arrow buttons to scrollbars
- gtk3: test with gtk 3.18: ok

Version 0.3, October 2015
- gtk2: fix shadow glitchs in the scrollbar design
- add a shell script to easily change the colors of the theme
- gtk3: improve calculation of shadows on buttons

Version 0.2, September 2015
- gtk3: fix borders glitchs in menus
- gtk3: improve borders of the embossed widgets
- gtk3: define help colors for borders
- gtk3: fix :hover colors on switchs
- gtk3: add support for gnome-logs selections
- fix color of insensitive combobox and check and radio buttons labels
- gtk2: fix color of gimp loading bar

Version 0.1, August 2015

- initial version

==[#11] Version numbering==

%~ $\forall n \in \mathbb{N}^*, v_n=1-0.1^{\int(n/9)}+\rest(n/9)*10^{-\int(n/9)-1}$.
Version 1 will be the definitive version...

==[#12] Download==

Current version:

- [OneStepBack-v0.997.zip OneStepBack-v0.997.zip]
- [OneStepBack-wm2-v0.997.zip OneStepBack-wm2-v0.997.zip]

Older versions:

- [OneStepBack-v0.996.zip OneStepBack-v0.996.zip]
- [OneStepBack-wm2-v0.996.zip OneStepBack-wm2-v0.996.zip]
- [OneStepBack-v0.995.zip OneStepBack-v0.995.zip]
- [OneStepBack-darker-v0.995.zip OneStepBack-darker-v0.995.zip]
- [OneStepBack-v0.994.zip OneStepBack-v0.994.zip]
- [OneStepBack-darker-v0.994.zip OneStepBack-darker-v0.994.zip]
- [OneStepBack-v0.993.zip OneStepBack-v0.993.zip]
- [OneStepBack-darker-v0.993.zip OneStepBack-darker-v0.993.zip]
- [OneStepBack-v0.992.zip OneStepBack-v0.992.zip]
- [OneStepBack-darker-v0.992.zip OneStepBack-darker-v0.992.zip]
- [OneStepBack-v0.991.zip OneStepBack-v0.991.zip]
- [OneStepBack-grey-brown-green-blue-v0.991.zip OneStepBack-grey-brown-green-blue-v0.991.zip]
- [OneStepBack-green-brown-v0.991.zip OneStepBack-green-brown-v0.991.zip]
- [OneStepBack-v0.99.zip OneStepBack-v0.99.zip]
- [OneStepBack-grey-brown-v0.99.zip OneStepBack-grey-brown-v0.99.zip]
- [OneStepBack-green-brown-v0.99.zip OneStepBack-green-brown-v0.99.zip]
- [OneStepBack-v0.98.zip OneStepBack-v0.98.zip]
- [OneStepBack-v0.97.zip OneStepBack-v0.97.zip]
- [OneStepBack-v0.96.zip OneStepBack-v0.96.zip]
- [OneStepBack-v0.94.zip OneStepBack-v0.94.zip]
- [OneStepBack-v0.91.zip OneStepBack-v0.91.zip]
- [OneStepBack-v0.9.zip OneStepBack-v0.9.zip]
- [OneStepBack-v0.7.zip OneStepBack-v0.7.zip] <--- Last version for Gtk+ 3.16 and 3.18
- [OneStepBack-v0.6.zip OneStepBack-v0.6.zip]
- [OneStepBack-v0.5.zip OneStepBack-v0.5.zip]
- [OneStepBack-v0.4.zip OneStepBack-v0.4.zip]
- [OneStepBack-v0.3.zip OneStepBack-v0.3.zip]
- [OneStepBack-v0.2.zip OneStepBack-v0.2.zip]
- [OneStepBack-v0.1.zip OneStepBack-v0.1.zip]

